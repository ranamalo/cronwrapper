A tool to wrap cron jobs and send an email if the exit status is non-zero or
stderr output is detected.
